/*
 * @(#)AWT_1_0_PopupBoxes.java				0.3 30/01/1998
 *
 *  This file is part of the HTTPClient package
 *  Copyright (C) 1996-1998  Ronald Tschalaer
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library; if not, write to the Free
 *  Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 *  MA 02111-1307, USA
 *
 *  For questions, suggestions, bug-reports, enhancement-requests etc.
 *  I may be contacted at:
 *
 *  ronald@innovation.ch
 *  Ronald.Tschalaer@psi.ch
 *
 */

package HTTPClient;

import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Event;
import java.awt.Color;
import java.awt.Button;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.TextField;
import java.awt.Rectangle;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;


/**
 * This file contains replacements for classes which use the AWT. The
 * versions in here use the old AWT event model used in JDK 1.0.2.
 *
 * @version	0.3  30/01/1998
 * @author	Ronald Tschal&auml;r
 */

/**
 * This class implements a simple popup that request username and password
 * used for the "basic" and "digest" authentication schemes. It uses the
 * old event model from JDK 1.0.2 .
 *
 * @version	0.3  10/12/1997
 * @author	Ronald Tschal&auml;r
 */
class BasicAuthBox extends Frame
{
    private final static String title = "Authorization Request";
    private Dimension           screen;
    private Label		line1;
    private Label		line2;
    private Label		line3;
    private TextField		user;
    private TextField		pass;
    private int                 done;
    private final static int    OK = 1, CANCEL = 0;


    /**
     * Constructs the popup with three lines of text above the input fields
     */
    BasicAuthBox()
    {
	super(title);

	screen = getToolkit().getScreenSize();

	addNotify();
	setLayout(new BorderLayout());

	Panel p = new Panel();
	p.setLayout(new GridLayout(3,1));
	p.add(line1 = new Label());
	p.add(line2 = new Label());
	p.add(line3 = new Label());
	add("North", p);

	p = new Panel();
	p.setLayout(new GridLayout(2,1));
	p.add(new Label("Username:"));
	p.add(new Label("Password:"));
	add("West", p);
	p = new Panel();
	p.setLayout(new GridLayout(2,1));
	p.add(user = new TextField(30));
	p.add(pass = new TextField(30));
	pass.setEchoCharacter('*');
	add("East", p);

	p = new Panel();
	GridBagLayout gb = new GridBagLayout();
	p.setLayout(gb);
	GridBagConstraints constr = new GridBagConstraints();
	Panel pp = new Panel();
	p.add(pp);
	constr.gridwidth = GridBagConstraints.REMAINDER;
	gb.setConstraints(pp, constr);
	constr.gridwidth = 1;
	Button b;
	p.add(b = new Button("  OK  "));
	constr.weightx = 1.0;
	gb.setConstraints(b, constr);
	p.add(b = new Button("Clear"));
	constr.weightx = 2.0;
	gb.setConstraints(b, constr);
	p.add(b = new Button("Cancel"));
	constr.weightx   = 1.0;
	gb.setConstraints(b, constr);
	add("South", p);

	pack();
	setResizable(false);
    }


    /**
     * our event handler
     */
    public boolean action(Event event, Object obj)
    {
	if (obj.equals("  OK  ")  ||  event.target == pass)
	{
	    done = OK;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Clear"))
	{
	    user.setText("");
	    pass.setText("");
	    user.requestFocus();
	    return true;
	}

	if (obj.equals("Cancel"))
	{
	    done = CANCEL;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.action(event, obj);
    }


    public boolean handleEvent(Event evt)
    {
	if (evt.id == Event.WINDOW_DESTROY)
	{
	    done = CANCEL;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.handleEvent(evt);
    }


    /**
     * the method called by MyAuthHandler.
     *
     * @return the username/password pair
     */
    synchronized NVPair getInput(String l1, String l2, String l3)
    {
	line1.setText(l1);
	line2.setText(l2);
	line3.setText(l3);

	line1.invalidate();
	line2.invalidate();
	line3.invalidate();

	pack();
	move((screen.width-preferredSize().width)/2,
	     (int) ((screen.height-preferredSize().height)/2*.7));
	user.requestFocus();
	show();

	try { wait(); } catch (InterruptedException e) { }

	hide();

	NVPair result = new NVPair(user.getText(), pass.getText());
	user.setText("");
	pass.setText("");

	if (done == CANCEL)
	    return null;
	else
	    return result;
    }
}


/**
 * A simple popup that asks whether the cookie should be accepted or rejected,
 * or if cookies from whole domains should be silently accepted or rejected.
 * It uses the old event model from JDK 1.0.2 .
 *
 * @version	0.3  30/01/1998
 * @author	Ronald Tschal&auml;r
 */
class BasicCookieBox extends Frame
{
    private final static String title = "Set Cookie Request";
    private Dimension           screen;
    private Label		name_value_label;
    private Label		domain_label;
    private Label		path_label;
    private Label		expires_label;
    private Label		secure_label;
    private TextField		domain;
    private Button		default_focus;
    private boolean             accept;
    private boolean             accept_domain;


    /**
     * Constructs the popup.
     */
    BasicCookieBox()
    {
	super(title);
	screen = getToolkit().getScreenSize();
	addNotify();

	GridBagLayout layout;
	setLayout(layout = new GridBagLayout());
	GridBagConstraints constr = new GridBagConstraints();

	Label header_label =
		new Label("The server would like to set the following cookie:");
	add(header_label);
	constr.gridwidth = GridBagConstraints.REMAINDER;
	constr.anchor = GridBagConstraints.WEST;
	layout.setConstraints(header_label, constr);

	Panel p = new Panel();
	Panel pp = new Panel();
	pp.setLayout(new GridLayout(4,1));
	pp.add(new Label("Name=Value:"));
	pp.add(new Label("Domain:"));
	pp.add(new Label("Path:"));
	pp.add(new Label("Expires:"));
	p.add(pp);

	pp = new Panel();
	pp.setLayout(new GridLayout(4,1));
	pp.add(name_value_label = new Label());
	pp.add(domain_label = new Label());
	pp.add(path_label = new Label());
	pp.add(expires_label = new Label());
	p.add(pp);
	add(p);
	layout.setConstraints(p, constr);
	add(secure_label = new Label(""));
	layout.setConstraints(secure_label, constr);

	add(default_focus = new Button("Accept"));
	constr.gridwidth = 1;
	constr.anchor = GridBagConstraints.CENTER;
	constr.weightx = 1.0;
	layout.setConstraints(default_focus, constr);

	Button b;
	add(b= new Button("Reject"));
	constr.gridwidth = GridBagConstraints.REMAINDER;
	layout.setConstraints(b, constr);

	constr.weightx = 0.0;
	p = new Separator();
	add(p);
	constr.fill = GridBagConstraints.HORIZONTAL;
	layout.setConstraints(p, constr);

	header_label =
	    new Label("Accept/Reject all cookies from a host or domain:");
	add(header_label);
	constr.fill   = GridBagConstraints.NONE;
	constr.anchor = GridBagConstraints.WEST;
	layout.setConstraints(header_label, constr);

	p = new Panel();
	p.add(new Label("Host/Domain:"));
	p.add(domain = new TextField(30));
	add(p);
	layout.setConstraints(p, constr);

        header_label =
	    new Label("domains are characterized by a leading dot (`.')");
	add(header_label);
	layout.setConstraints(header_label, constr);
        header_label = new Label("(an empty string matches all hosts)");
	add(header_label);
	layout.setConstraints(header_label, constr);

	add(b = new Button("Accept All"));
	constr.anchor    = GridBagConstraints.CENTER;
	constr.gridwidth = 1;
	constr.weightx   = 1.0;
	layout.setConstraints(b, constr);

	add(b = new Button("Reject All"));
	constr.gridwidth = GridBagConstraints.REMAINDER;
	layout.setConstraints(b, constr);

	pack();
	setResizable(false);
    }


    /**
     * our event handler
     */
    public boolean action(Event event, Object obj)
    {
	if (obj.equals("Accept"))
	{
	    accept = true;
	    accept_domain = false;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Reject"))
	{
	    accept = false;
	    accept_domain = false;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Accept All"))
	{
	    accept = true;
	    accept_domain = true;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	if (obj.equals("Reject All"))
	{
	    accept = false;
	    accept_domain = true;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.action(event, obj);
    }


    public boolean handleEvent(Event evt)
    {
	if (evt.id == Event.WINDOW_DESTROY)
	{
	    accept = false;
	    accept_domain = false;
	    synchronized (this) { notifyAll(); }
	    return true;
	}

	return super.handleEvent(evt);
    }


    /**
     * the method called by the DefaultCookiePolicyHandler.
     *
     * @return the username/password pair
     */
    synchronized boolean accept(Cookie cookie, DefaultCookiePolicyHandler h,
				String server)
    {
	// set the new values

	name_value_label.setText(cookie.getName() + "=" + cookie.getValue());
	domain_label.setText(cookie.getDomain());
	path_label.setText(cookie.getPath());
	if (cookie.expires() == null)
	    expires_label.setText("at end of session");
	else
	    expires_label.setText(cookie.expires().toString());
	if (cookie.isSecure())
	    secure_label.setText("This cookie will only be sent over secure connections");
	else
	    secure_label.setText("");


	// invalidate all labels, so that new values are displayed correctly

	name_value_label.invalidate();
	domain_label.invalidate();
	path_label.invalidate();
	expires_label.invalidate();
	secure_label.invalidate();


	// set default domain test
 
	domain.setText(cookie.getDomain());


	// display

	pack();
	move((screen.width-preferredSize().width)/2,
	     (int) ((screen.height-preferredSize().height)/2*.7));
	default_focus.requestFocus();
	show();


	// wait for user input

	try { wait(); } catch (InterruptedException e) { }

	hide();


	// handle accept/reject domain buttons

	if (accept_domain)
	{
	    String dom = domain.getText().trim().toLowerCase();

	    if (accept)
		h.addAcceptDomain(dom);
	    else
		h.addRejectDomain(dom);

	    accept =
		accept != (dom.length() == 0  ||
			   dom.charAt(0) == '.'  &&  server.endsWith(dom)  ||
			   dom.charAt(0) != '.'  &&  server.equals(dom));
	}

	return accept;
    }
}


/**
 * A simple separator element.
 */
class Separator extends Panel
{
    public void paint(Graphics g)
    {
	int w = size().width,
	    h = size().height/2;

	g.setColor(Color.darkGray);
	g.drawLine(2, h-1, w-2, h-1);
	g.setColor(Color.white);
	g.drawLine(2, h, w-2, h);
    }

    public Dimension minimumSize()
    {
	return new Dimension(4, 2);
    }
}

